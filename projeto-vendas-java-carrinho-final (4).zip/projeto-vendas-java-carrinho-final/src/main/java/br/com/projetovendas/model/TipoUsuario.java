package br.com.projetovendas.model;

public enum TipoUsuario {
    USUARIO,
    ADMINISTRATIVO
}
