package br.com.projetovendas.view;

import br.com.projetovendas.model.Carrinho;
import br.com.projetovendas.model.CarrinhoItem;
import br.com.projetovendas.model.Produto;
import br.com.projetovendas.model.Usuario;
import br.com.projetovendas.service.PedidoService;
import br.com.projetovendas.service.ProdutoService;
import br.com.projetovendas.util.FormatUtil;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/**
 * Tela da área do cliente.
 * Permite buscar produtos, adicionar/remover do carrinho e confirmar a compra.
 * Exibe painel lateral com imagem e detalhes do produto selecionado.
 */
public class ClienteView {

    private final Usuario usuario;
    private final Stage stage;
    private final Carrinho carrinho = new Carrinho();
    private final ProdutoService produtoService = new ProdutoService();
    private final PedidoService pedidoService   = new PedidoService();

    private TableView<Produto>      tabelaProdutos;
    private TableView<CarrinhoItem> tabelaCarrinho;
    private ObservableList<Produto>      listaProdutos = FXCollections.observableArrayList();
    private ObservableList<CarrinhoItem> listaCarrinho = FXCollections.observableArrayList();

    // Painel de detalhes do produto
    private ImageView imgProduto;
    private Label lblDetalheNome;
    private Label lblDetalheDesc;
    private Label lblDetalhePreco;
    private Label lblDetalheEstoque;
    private VBox painelDetalhe;

    private Label lblTotal;
    private Label lblStatus;

    public ClienteView(Usuario usuario, Stage stage) {
        this.usuario = usuario;
        this.stage   = stage;
    }

    /**
     * Exibe a tela do cliente.
     */
    public void show() {
        stage.setTitle("Loja - " + usuario.getNome());

        // Cabeçalho
        Label titulo = new Label("Loja");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        titulo.setStyle("-fx-text-fill: white;");

        Label lblBemVindo = new Label("Olá, " + usuario.getNome() + "!");
        lblBemVindo.setStyle("-fx-text-fill: #bdc3c7;");

        Button btnLogout = new Button("Logout");
        btnLogout.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-background-radius: 5;");
        btnLogout.setOnAction(e -> {
            try { new LoginView().start(stage); } catch (Exception ex) { ex.printStackTrace(); }
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox cabecalho = new HBox(10, titulo, spacer, lblBemVindo, btnLogout);
        cabecalho.setAlignment(Pos.CENTER_LEFT);
        cabecalho.setPadding(new Insets(10, 16, 10, 16));
        cabecalho.setStyle("-fx-background-color: #27ae60;");

        // Layout: tabela | detalhe produto | carrinho
        SplitPane split = new SplitPane(painelProdutos(), painelDetalheProduto(), painelCarrinho());
        split.setDividerPositions(0.40, 0.65);

        // Status bar
        lblStatus = new Label("Bem-vindo(a)! Selecione um produto para ver os detalhes.");
        lblStatus.setStyle("-fx-text-fill: #555; -fx-padding: 4 12;");

        VBox root = new VBox(cabecalho, split, lblStatus);
        VBox.setVgrow(split, Priority.ALWAYS);

        stage.setScene(new Scene(root, 1100, 660));
        stage.show();

        carregarProdutos();
    }

    // ─── Painel Produtos (tabela) ─────────────────────────────────────────────────

    private VBox painelProdutos() {
        Label titulo = new Label("Produtos disponíveis");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 14));

        TextField campoBusca = new TextField();
        campoBusca.setPromptText("Buscar por nome ou ID...");
        campoBusca.setPrefWidth(180);

        Button btnBuscar     = botao("Buscar", "#2980b9");
        Button btnListarTodos = botao("Todos", "#7f8c8d");

        btnBuscar.setOnAction(e -> buscarProduto(campoBusca.getText()));
        campoBusca.setOnAction(e -> buscarProduto(campoBusca.getText()));
        btnListarTodos.setOnAction(e -> { campoBusca.clear(); carregarProdutos(); });

        HBox barraBusca = new HBox(6, campoBusca, btnBuscar, btnListarTodos);
        barraBusca.setAlignment(Pos.CENTER_LEFT);

        tabelaProdutos = new TableView<>();
        tabelaProdutos.setItems(listaProdutos);
        tabelaProdutos.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Produto, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colId.setMaxWidth(40);

        TableColumn<Produto, String> colNome = new TableColumn<>("Nome");
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));

        TableColumn<Produto, BigDecimal> colPreco = new TableColumn<>("Preço");
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));
        colPreco.setMaxWidth(80);

        TableColumn<Produto, Integer> colEst = new TableColumn<>("Estoque");
        colEst.setCellValueFactory(new PropertyValueFactory<>("estoque"));
        colEst.setMaxWidth(65);

        tabelaProdutos.getColumns().addAll(colId, colNome, colPreco, colEst);

        // Ao selecionar linha → atualiza painel de detalhe
        tabelaProdutos.getSelectionModel().selectedItemProperty().addListener(
                (obs, anterior, selecionado) -> atualizarDetalheProduto(selecionado));

        // Spinner de quantidade
        Label lblQtd = new Label("Qtd:");
        Spinner<Integer> spinnerQtd = new Spinner<>(1, 999, 1);
        spinnerQtd.setPrefWidth(70);
        spinnerQtd.setEditable(true);

        Button btnAdicionar = botao("+ Adicionar ao Carrinho", "#27ae60");
        btnAdicionar.setOnAction(e -> {
            Produto p = tabelaProdutos.getSelectionModel().getSelectedItem();
            if (p == null) { setStatus("Selecione um produto para adicionar."); return; }
            adicionarAoCarrinho(p, spinnerQtd.getValue());
        });

        HBox rodape = new HBox(8, lblQtd, spinnerQtd, btnAdicionar);
        rodape.setAlignment(Pos.CENTER_LEFT);

        VBox painel = new VBox(8, titulo, barraBusca, tabelaProdutos, rodape);
        painel.setPadding(new Insets(12));
        VBox.setVgrow(tabelaProdutos, Priority.ALWAYS);
        return painel;
    }

    // ─── Painel Detalhe do Produto ────────────────────────────────────────────────

    private VBox painelDetalheProduto() {
        Label titulo = new Label("Detalhes do Produto");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 14));

        // ImageView com placeholder
        imgProduto = new ImageView();
        imgProduto.setFitWidth(220);
        imgProduto.setFitHeight(220);
        imgProduto.setPreserveRatio(true);
        imgProduto.setSmooth(true);
        imgProduto.setStyle("-fx-background-color: #ecf0f1;");

        // Placeholder visual quando não há imagem
        StackPane imgContainer = new StackPane();
        imgContainer.setPrefSize(220, 220);
        imgContainer.setMaxWidth(220);
        imgContainer.setStyle("-fx-background-color: #ecf0f1; -fx-background-radius: 8; -fx-border-color: #bdc3c7; -fx-border-radius: 8;");

        Label lblSemImagem = new Label("Sem imagem");
        lblSemImagem.setStyle("-fx-text-fill: #95a5a6; -fx-font-size: 13;");

        imgContainer.getChildren().addAll(lblSemImagem, imgProduto);

        // Labels de detalhe
        lblDetalheNome = new Label("—");
        lblDetalheNome.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        lblDetalheNome.setWrapText(true);

        lblDetalheDesc = new Label("—");
        lblDetalheDesc.setStyle("-fx-text-fill: #555;");
        lblDetalheDesc.setWrapText(true);

        lblDetalhePreco = new Label("—");
        lblDetalhePreco.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        lblDetalhePreco.setStyle("-fx-text-fill: #27ae60;");

        lblDetalheEstoque = new Label("—");
        lblDetalheEstoque.setStyle("-fx-text-fill: #888; -fx-font-size: 12;");

        Separator sep = new Separator();

        painelDetalhe = new VBox(10,
                titulo,
                imgContainer,
                sep,
                lblDetalheNome,
                lblDetalheDesc,
                lblDetalhePreco,
                lblDetalheEstoque
        );
        painelDetalhe.setPadding(new Insets(12));
        painelDetalhe.setAlignment(Pos.TOP_CENTER);
        painelDetalhe.setStyle("-fx-background-color: #f9f9f9;");

        return painelDetalhe;
    }

    /**
     * Atualiza o painel lateral com os dados e imagem do produto selecionado.
     */
    private void atualizarDetalheProduto(Produto p) {
        if (p == null) {
            imgProduto.setImage(null);
            lblDetalheNome.setText("—");
            lblDetalheDesc.setText("—");
            lblDetalhePreco.setText("—");
            lblDetalheEstoque.setText("—");
            return;
        }

        lblDetalheNome.setText(p.getNome());
        lblDetalheDesc.setText(p.getDescricao() != null && !p.getDescricao().isEmpty()
                ? p.getDescricao() : "Sem descrição");
        lblDetalhePreco.setText(FormatUtil.moeda(p.getPreco()));
        lblDetalheEstoque.setText("Estoque disponível: " + p.getEstoque() + " unidade(s)");

        // Carregar imagem (URL http/https ou caminho local)
        String url = p.getImg();
        if (url != null && !url.trim().isEmpty()) {
            try {
                Image img;
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    img = new Image(url, 220, 220, true, true, true); // carregamento assíncrono
                } else {
                    // Caminho local: ex: C:\imagens\produto.jpg ou /home/user/img.png
                    img = new Image("file:///" + url.replace("\\", "/"), 220, 220, true, true, true);
                }
                imgProduto.setImage(img);
            } catch (Exception e) {
                imgProduto.setImage(null); // Imagem inválida → mostra placeholder
            }
        } else {
            imgProduto.setImage(null);
        }
    }

    // ─── Painel Carrinho ──────────────────────────────────────────────────────────

    private VBox painelCarrinho() {
        Label titulo = new Label("Meu Carrinho");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 14));

        tabelaCarrinho = new TableView<>();
        tabelaCarrinho.setItems(listaCarrinho);
        tabelaCarrinho.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<CarrinhoItem, String> colNome = new TableColumn<>("Produto");
        colNome.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getProduto().getNome()));

        TableColumn<CarrinhoItem, Integer> colQtd = new TableColumn<>("Qtd");
        colQtd.setCellValueFactory(c -> new SimpleIntegerProperty(c.getValue().getQuantidade()).asObject());
        colQtd.setMaxWidth(45);

        TableColumn<CarrinhoItem, String> colPreco = new TableColumn<>("Unit.");
        colPreco.setCellValueFactory(c -> new SimpleStringProperty(
                FormatUtil.moeda(c.getValue().getProduto().getPreco())));
        colPreco.setMaxWidth(80);

        TableColumn<CarrinhoItem, String> colSub = new TableColumn<>("Subtotal");
        colSub.setCellValueFactory(c -> new SimpleStringProperty(
                FormatUtil.moeda(c.getValue().getSubtotal())));
        colSub.setMaxWidth(90);

        tabelaCarrinho.getColumns().addAll(colNome, colQtd, colPreco, colSub);

        lblTotal = new Label("Total: R$ 0,00");
        lblTotal.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblTotal.setStyle("-fx-text-fill: #27ae60;");

        Button btnRemover   = botao("✕ Remover Item", "#e74c3c");
        Button btnConfirmar = botao("✔ Confirmar Compra", "#2980b9");
        btnConfirmar.setPrefWidth(Double.MAX_VALUE);

        btnRemover.setOnAction(e -> {
            CarrinhoItem item = tabelaCarrinho.getSelectionModel().getSelectedItem();
            if (item == null) { setStatus("Selecione um item para remover."); return; }
            carrinho.removerProduto(item.getProduto().getId());
            atualizarCarrinhoView();
            setStatus("Item removido do carrinho.");
        });

        btnConfirmar.setOnAction(e -> confirmarCompra());

        VBox painel = new VBox(8, titulo, tabelaCarrinho, new HBox(btnRemover), lblTotal, btnConfirmar);
        painel.setPadding(new Insets(12));
        VBox.setVgrow(tabelaCarrinho, Priority.ALWAYS);
        return painel;
    }

    // ─── Ações ────────────────────────────────────────────────────────────────────

    private void carregarProdutos() {
        try {
            listaProdutos.setAll(produtoService.listarTodos());
            setStatus(listaProdutos.size() + " produto(s) disponível(is). Clique em um para ver os detalhes.");
        } catch (SQLException e) {
            alertaErro("Erro ao carregar produtos: " + e.getMessage());
        }
    }

    private void buscarProduto(String termo) {
        if (termo == null || termo.trim().isEmpty()) { carregarProdutos(); return; }
        try {
            List<Produto> resultado = produtoService.buscarPorNomeOuId(termo.trim());
            listaProdutos.setAll(resultado);
            setStatus(resultado.isEmpty() ? "Nenhum produto encontrado." : resultado.size() + " encontrado(s).");
        } catch (Exception e) {
            alertaErro("Erro na busca: " + e.getMessage());
        }
    }

    private void adicionarAoCarrinho(Produto produto, int quantidade) {
        if (produto.getEstoque() <= 0) {
            setStatus("Produto sem estoque disponível.");
            return;
        }
        int jaNoCarrinho = carrinho.getQuantidadeProduto(produto.getId());
        if (jaNoCarrinho + quantidade > produto.getEstoque()) {
            setStatus("Estoque insuficiente. Disponível: " + produto.getEstoque()
                    + " | Já no carrinho: " + jaNoCarrinho);
            return;
        }
        carrinho.adicionarProduto(produto, quantidade);
        atualizarCarrinhoView();
        setStatus("\"" + produto.getNome() + "\" adicionado ao carrinho (x" + quantidade + ").");
    }

    private void confirmarCompra() {
        if (carrinho.estaVazio()) {
            setStatus("Carrinho vazio. Adicione produtos antes de confirmar.");
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Total: " + FormatUtil.moeda(carrinho.getTotal()) + "\n\nConfirmar compra?",
                ButtonType.YES, ButtonType.NO);
        confirm.setHeaderText("Confirmar Compra");
        Optional<ButtonType> resp = confirm.showAndWait();

        if (resp.isPresent() && resp.get() == ButtonType.YES) {
            try {
                int pedidoId = pedidoService.confirmarCompra(usuario, carrinho);
                carrinho.limpar();
                atualizarCarrinhoView();
                carregarProdutos();
                Alert ok = new Alert(Alert.AlertType.INFORMATION,
                        "Pedido #" + pedidoId + " confirmado com sucesso!\nEstoque atualizado.",
                        ButtonType.OK);
                ok.setHeaderText("Compra realizada!");
                ok.showAndWait();
                setStatus("Compra confirmada! Pedido #" + pedidoId);
            } catch (IllegalArgumentException e) {
                alertaErro("Erro de validação: " + e.getMessage());
            } catch (SQLException e) {
                alertaErro("Erro ao confirmar compra: " + e.getMessage());
            }
        }
    }

    private void atualizarCarrinhoView() {
        listaCarrinho.setAll(carrinho.getItens());
        lblTotal.setText("Total: " + FormatUtil.moeda(carrinho.getTotal()));
    }

    // ─── Utilitários ──────────────────────────────────────────────────────────────

    private Button botao(String texto, String cor) {
        Button b = new Button(texto);
        b.setStyle("-fx-background-color: " + cor + "; -fx-text-fill: white; -fx-background-radius: 5; -fx-padding: 6 12;");
        return b;
    }

    private void setStatus(String msg) {
        if (lblStatus != null) lblStatus.setText(msg);
    }

    private void alertaErro(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        alert.setHeaderText("Erro");
        alert.showAndWait();
    }
}
