package br.com.projetovendas.service;

import br.com.projetovendas.dao.ProdutoDAO;
import br.com.projetovendas.model.Produto;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class ProdutoService {
    private ProdutoDAO produtoDAO;

    public ProdutoService() {
        this.produtoDAO = new ProdutoDAO();
    }

    public void cadastrarProduto(String nome, String descricao, BigDecimal preco, int estoque, String img) throws SQLException {
        validarProduto(nome, descricao, preco, estoque);

        Produto produto = new Produto();
        produto.setNome(nome.trim());
        produto.setDescricao(descricao.trim());
        produto.setPreco(preco);
        produto.setEstoque(estoque);
        produto.setImg(img == null ? "" : img.trim());

        produtoDAO.inserir(produto);
    }

    public boolean atualizarProduto(Produto produto) throws SQLException {
        validarProduto(produto.getNome(), produto.getDescricao(), produto.getPreco(), produto.getEstoque());
        return produtoDAO.atualizar(produto);
    }

    public boolean removerProduto(int id) throws SQLException {
        return produtoDAO.remover(id);
    }

    public Produto buscarPorId(int id) throws SQLException {
        return produtoDAO.buscarPorId(id);
    }

    public List<Produto> buscarPorNomeOuId(String termo) throws SQLException {
        if (termo == null || termo.trim().isEmpty()) {
            throw new IllegalArgumentException("Informe um nome ou ID para buscar.");
        }
        return produtoDAO.buscarPorNomeOuId(termo.trim());
    }

    public List<Produto> listarTodos() throws SQLException {
        return produtoDAO.listarTodos();
    }

    private void validarProduto(String nome, String descricao, BigDecimal preco, int estoque) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do produto eh obrigatorio.");
        }
        if (descricao == null || descricao.trim().isEmpty()) {
            throw new IllegalArgumentException("Descricao do produto eh obrigatoria.");
        }
        if (preco == null || preco.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Preco do produto precisa ser maior que zero.");
        }
        if (estoque < 0) {
            throw new IllegalArgumentException("Estoque nao pode ser negativo.");
        }
    }
}
