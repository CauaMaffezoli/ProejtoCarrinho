package br.com.projetovendas.util;

import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.Locale;

public class FormatUtil {
    private static final NumberFormat MOEDA = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("pt-BR"));

    public static String moeda(BigDecimal valor) {
        if (valor == null) {
            return MOEDA.format(BigDecimal.ZERO);
        }
        return MOEDA.format(valor);
    }
}
