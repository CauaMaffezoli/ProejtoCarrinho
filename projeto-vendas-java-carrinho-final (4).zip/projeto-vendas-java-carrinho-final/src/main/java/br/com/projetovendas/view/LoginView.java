package br.com.projetovendas.view;

import br.com.projetovendas.model.TipoUsuario;
import br.com.projetovendas.model.Usuario;
import br.com.projetovendas.service.UsuarioService;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.sql.SQLException;

/**
 * Tela de login da aplicação.
 * Permite autenticação como usuário comum ou administrador,
 * e também acesso ao cadastro de novo usuário.
 */
public class LoginView extends Application {

    private UsuarioService usuarioService = new UsuarioService();

    @Override
    public void start(Stage stage) {
        stage.setTitle("Sistema de Vendas - Login");

        // Título
        Label titulo = new Label("Sistema de Vendas");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 22));

        Label subtitulo = new Label("Faça login para continuar");
        subtitulo.setFont(Font.font("Arial", 13));
        subtitulo.setStyle("-fx-text-fill: #666;");

        // Campos
        TextField campoLogin = new TextField();
        campoLogin.setPromptText("Login");
        campoLogin.setPrefHeight(36);

        PasswordField campoSenha = new PasswordField();
        campoSenha.setPromptText("Senha");
        campoSenha.setPrefHeight(36);

        // Tipo de usuário
        Label labelTipo = new Label("Entrar como:");
        ToggleGroup grupo = new ToggleGroup();
        RadioButton rbUsuario = new RadioButton("Usuário");
        RadioButton rbAdmin  = new RadioButton("Administrador");
        rbUsuario.setToggleGroup(grupo);
        rbAdmin.setToggleGroup(grupo);
        rbUsuario.setSelected(true);

        HBox boxTipo = new HBox(16, rbUsuario, rbAdmin);
        boxTipo.setAlignment(Pos.CENTER_LEFT);

        // Mensagem de erro
        Label lblErro = new Label();
        lblErro.setStyle("-fx-text-fill: #c0392b;");
        lblErro.setWrapText(true);

        // Botão Login
        Button btnLogin = new Button("Entrar");
        btnLogin.setPrefWidth(Double.MAX_VALUE);
        btnLogin.setPrefHeight(38);
        btnLogin.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-size: 14; -fx-background-radius: 6;");

        btnLogin.setOnAction(e -> {
            lblErro.setText("");
            String login = campoLogin.getText().trim();
            String senha = campoSenha.getText().trim();

            if (login.isEmpty() || senha.isEmpty()) {
                lblErro.setText("Preencha login e senha.");
                return;
            }

            TipoUsuario tipo = rbAdmin.isSelected() ? TipoUsuario.ADMINISTRATIVO : TipoUsuario.USUARIO;

            try {
                Usuario usuario = usuarioService.autenticar(login, senha, tipo);
                if (usuario == null) {
                    lblErro.setText("Login ou senha incorretos, ou tipo de usuário inválido.");
                } else {
                    if (tipo == TipoUsuario.ADMINISTRATIVO) {
                        new AdminView(usuario).start(stage);
                    } else {
                        new ClienteView(usuario, stage).show();
                    }
                }
            } catch (SQLException ex) {
                lblErro.setText("Erro ao conectar ao banco: " + ex.getMessage());
            } catch (Exception ex) {
                lblErro.setText("Erro inesperado: " + ex.getMessage());
            }
        });

        // Permitir Enter nos campos
        campoLogin.setOnAction(e -> btnLogin.fire());
        campoSenha.setOnAction(e -> btnLogin.fire());

        // Link para cadastro
        Hyperlink linkCadastro = new Hyperlink("Não tem conta? Cadastre-se");
        linkCadastro.setStyle("-fx-text-fill: #2980b9;");
        linkCadastro.setOnAction(e -> new CadastroView(stage).show());

        // Layout
        VBox form = new VBox(10,
                titulo, subtitulo,
                new Separator(),
                new Label("Login:"), campoLogin,
                new Label("Senha:"), campoSenha,
                labelTipo, boxTipo,
                lblErro,
                btnLogin,
                linkCadastro
        );
        form.setPadding(new Insets(30));
        form.setMaxWidth(360);
        form.setAlignment(Pos.CENTER_LEFT);

        StackPane root = new StackPane(form);
        root.setStyle("-fx-background-color: #f4f6f8;");
        StackPane.setAlignment(form, Pos.CENTER);

        Scene scene = new Scene(root, 420, 480);
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
}
