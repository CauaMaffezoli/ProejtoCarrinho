package br.com.projetovendas.service;

import br.com.projetovendas.config.ConnectionFactory;
import br.com.projetovendas.dao.PedidoDAO;
import br.com.projetovendas.dao.ProdutoDAO;
import br.com.projetovendas.model.Carrinho;
import br.com.projetovendas.model.CarrinhoItem;
import br.com.projetovendas.model.Pedido;
import br.com.projetovendas.model.PedidoItem;
import br.com.projetovendas.model.Produto;
import br.com.projetovendas.model.Usuario;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PedidoService {
    private PedidoDAO pedidoDAO;
    private ProdutoDAO produtoDAO;

    public PedidoService() {
        this.pedidoDAO = new PedidoDAO();
        this.produtoDAO = new ProdutoDAO();
    }

    public int confirmarCompra(Usuario usuario, Carrinho carrinho) throws SQLException {
        if (usuario == null) {
            throw new IllegalArgumentException("Usuario nao esta logado.");
        }

        if (carrinho == null || carrinho.estaVazio()) {
            throw new IllegalArgumentException("Carrinho vazio. Adicione produtos antes de confirmar a compra.");
        }

        Connection conn = null;

        try {
            conn = ConnectionFactory.getConnection();
            conn.setAutoCommit(false);

            List<PedidoItem> itensPedido = new ArrayList<PedidoItem>();
            BigDecimal totalAtualizado = BigDecimal.ZERO;

            for (CarrinhoItem itemCarrinho : carrinho.getItens()) {
                Produto produtoAtual = produtoDAO.buscarPorIdComBloqueio(conn, itemCarrinho.getProduto().getId());

                if (produtoAtual == null) {
                    throw new IllegalArgumentException("Produto ID " + itemCarrinho.getProduto().getId() + " nao existe mais no banco.");
                }

                if (produtoAtual.getEstoque() < itemCarrinho.getQuantidade()) {
                    throw new IllegalArgumentException("Estoque insuficiente para o produto: " + produtoAtual.getNome() +
                            ". Estoque atual: " + produtoAtual.getEstoque() +
                            ". Quantidade no carrinho: " + itemCarrinho.getQuantidade() + ".");
                }

                PedidoItem itemPedido = new PedidoItem();
                itemPedido.setProduto(produtoAtual);
                itemPedido.setQuantidade(itemCarrinho.getQuantidade());
                itemPedido.setPrecoUnitario(produtoAtual.getPreco());
                itensPedido.add(itemPedido);
                totalAtualizado = totalAtualizado.add(itemPedido.getSubtotal());
            }

            Pedido pedido = new Pedido();
            pedido.setUsuario(usuario);
            pedido.setDataPedido(LocalDateTime.now());
            pedido.setStatus("CONFIRMADO");
            pedido.setTotal(totalAtualizado);
            pedido.setItens(itensPedido);

            int pedidoId = pedidoDAO.inserirPedido(conn, pedido);

            for (PedidoItem item : itensPedido) {
                item.setPedidoId(pedidoId);
                pedidoDAO.inserirItem(conn, pedidoId, item);

                boolean estoqueBaixado = produtoDAO.baixarEstoque(conn, item.getProduto().getId(), item.getQuantidade());
                if (!estoqueBaixado) {
                    throw new IllegalArgumentException("Nao foi possivel baixar o estoque do produto: " + item.getProduto().getNome());
                }
            }

            conn.commit();
            return pedidoId;
        } catch (SQLException e) {
            rollback(conn);
            throw e;
        } catch (RuntimeException e) {
            rollback(conn);
            throw e;
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }

    private void rollback(Connection conn) {
        if (conn != null) {
            try {
                conn.rollback();
            } catch (SQLException e) {
                System.out.println("Erro ao desfazer transacao: " + e.getMessage());
            }
        }
    }
}
