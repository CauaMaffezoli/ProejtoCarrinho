package br.com.projetovendas.dao;

import br.com.projetovendas.config.ConnectionFactory;
import br.com.projetovendas.model.TipoUsuario;
import br.com.projetovendas.model.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    public void inserir(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO usuarios (nome, sobrenome, login, senha, tipo) VALUES (?, ?, ?, ?, ?)";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getSobrenome());
            stmt.setString(3, usuario.getLogin());
            stmt.setString(4, usuario.getSenha());
            stmt.setString(5, usuario.getTipo().name());
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                usuario.setId(rs.getInt(1));
            }
            rs.close();
        } finally {
            fechar(stmt, conn);
        }
    }

    public Usuario buscarPorLogin(String login) throws SQLException {
        String sql = "SELECT id, nome, sobrenome, login, senha, tipo FROM usuarios WHERE LOWER(login) = LOWER(?)";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, login);
            rs = stmt.executeQuery();

            if (rs.next()) {
                return montarUsuario(rs);
            }
            return null;
        } finally {
            fechar(rs, stmt, conn);
        }
    }

    public Usuario autenticar(String login, String senha, TipoUsuario tipo) throws SQLException {
        String sql = "SELECT id, nome, sobrenome, login, senha, tipo " +
                "FROM usuarios " +
                "WHERE LOWER(login) = LOWER(?) AND senha = ? AND tipo = ?";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, login);
            stmt.setString(2, senha);
            stmt.setString(3, tipo.name());
            rs = stmt.executeQuery();

            if (rs.next()) {
                return montarUsuario(rs);
            }
            return null;
        } finally {
            fechar(rs, stmt, conn);
        }
    }

    public List<Usuario> listarUsuariosComuns() throws SQLException {
        String sql = "SELECT id, nome, sobrenome, login, senha, tipo FROM usuarios WHERE tipo = 'USUARIO' ORDER BY nome";
        List<Usuario> usuarios = new ArrayList<Usuario>();

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                usuarios.add(montarUsuario(rs));
            }
            return usuarios;
        } finally {
            fechar(rs, stmt, conn);
        }
    }

    public boolean removerUsuarioComum(int id) throws SQLException {
        String sql = "DELETE FROM usuarios WHERE id = ? AND tipo = 'USUARIO'";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } finally {
            fechar(stmt, conn);
        }
    }

    private Usuario montarUsuario(ResultSet rs) throws SQLException {
        Usuario usuario = new Usuario();
        usuario.setId(rs.getInt("id"));
        usuario.setNome(rs.getString("nome"));
        usuario.setSobrenome(rs.getString("sobrenome"));
        usuario.setLogin(rs.getString("login"));
        usuario.setSenha(rs.getString("senha"));
        usuario.setTipo(TipoUsuario.valueOf(rs.getString("tipo")));
        return usuario;
    }

    private void fechar(Statement stmt, Connection conn) throws SQLException {
        if (stmt != null) {
            stmt.close();
        }
        if (conn != null) {
            conn.close();
        }
    }

    private void fechar(ResultSet rs, Statement stmt, Connection conn) throws SQLException {
        if (rs != null) {
            rs.close();
        }
        fechar(stmt, conn);
    }
}
