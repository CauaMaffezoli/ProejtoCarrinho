package br.com.projetovendas.app;

import br.com.projetovendas.model.Carrinho;
import br.com.projetovendas.model.CarrinhoItem;
import br.com.projetovendas.model.Produto;
import br.com.projetovendas.model.TipoUsuario;
import br.com.projetovendas.model.Usuario;
import br.com.projetovendas.service.PedidoService;
import br.com.projetovendas.service.ProdutoService;
import br.com.projetovendas.service.UsuarioService;
import br.com.projetovendas.util.FormatUtil;
import br.com.projetovendas.util.InputUtil;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class AppController {
    private Scanner scanner;
    private InputUtil input;
    private UsuarioService usuarioService;
    private ProdutoService produtoService;
    private PedidoService pedidoService;

    public AppController() {
        this.scanner = new Scanner(System.in);
        this.input = new InputUtil(scanner);
        this.usuarioService = new UsuarioService();
        this.produtoService = new ProdutoService();
        this.pedidoService = new PedidoService();
    }

    public void iniciar() {
        int opcao;

        do {
            mostrarCabecalho("SISTEMA DE LOJA - MENU");
            System.out.println("1 - Cadastrar Novo Usuario");
            System.out.println("2 - Efetuar Login - Usuario");
            System.out.println("3 - Efetuar Login - Administrativo");
            System.out.println("0 - Sair");
            opcao = input.lerInteiro("Escolha uma opcao: ");

            if (opcao == 1) {
                cadastrarUsuario();
            } else if (opcao == 2) {
                efetuarLogin(TipoUsuario.USUARIO);
            } else if (opcao == 3) {
                efetuarLogin(TipoUsuario.ADMINISTRATIVO);
            } else if (opcao == 0) {
                System.out.println("Sistema encerrado.");
            } else {
                System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private void cadastrarUsuario() {
        mostrarCabecalho("CADASTRO DE USUARIO");

        try {
            String nome = input.lerTextoObrigatorio("Nome: ");
            String sobrenome = input.lerTextoObrigatorio("Sobrenome: ");
            String login = input.lerTextoObrigatorio("Login: ");
            String senha = input.lerTextoObrigatorio("Senha minimo 8 caracteres: ");
            String confirmacaoSenha = input.lerTextoObrigatorio("Confirme a senha: ");

            usuarioService.cadastrarUsuario(nome, sobrenome, login, senha, confirmacaoSenha);
            System.out.println("Usuario cadastrado com sucesso!");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro de validacao: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro ao salvar usuario no banco: " + e.getMessage());
        }
    }

    private void efetuarLogin(TipoUsuario tipoUsuario) {
        if (tipoUsuario == TipoUsuario.ADMINISTRATIVO) {
            mostrarCabecalho("LOGIN - ADMINISTRATIVO");
        } else {
            mostrarCabecalho("LOGIN - USUARIO");
        }

        try {
            String login = input.lerTextoObrigatorio("Login: ");
            String senha = input.lerTextoObrigatorio("Senha: ");

            Usuario usuario = usuarioService.autenticar(login, senha, tipoUsuario);

            if (usuario == null) {
                System.out.println("Login ou senha incorretos, ou tipo de usuario invalido.");
                return;
            }

            System.out.println("Login realizado com sucesso. Bem-vindo(a), " + usuario.getNome() + "!");

            if (tipoUsuario == TipoUsuario.ADMINISTRATIVO) {
                menuAdministrativo(usuario);
            } else {
                menuCliente(usuario);
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Erro de validacao: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro ao consultar banco de dados: " + e.getMessage());
        }
    }

    private void menuAdministrativo(Usuario admin) {
        int opcao;

        do {
            mostrarCabecalho("AREA ADMINISTRATIVA");
            System.out.println("1 - Cadastrar novo produto");
            System.out.println("2 - Buscar produto");
            System.out.println("3 - Remover produto");
            System.out.println("4 - Atualizar produto");
            System.out.println("5 - Listar todos os produtos");
            System.out.println("6 - Listar usuarios cadastrados");
            System.out.println("7 - Remover usuario comum");
            System.out.println("0 - Fazer logout");
            opcao = input.lerInteiro("Escolha uma opcao: ");

            if (opcao == 1) {
                cadastrarProduto();
            } else if (opcao == 2) {
                buscarProduto();
            } else if (opcao == 3) {
                removerProduto();
            } else if (opcao == 4) {
                atualizarProduto();
            } else if (opcao == 5) {
                listarProdutos();
            } else if (opcao == 6) {
                listarUsuarios();
            } else if (opcao == 7) {
                removerUsuarioComum();
            } else if (opcao == 0) {
                System.out.println("Logout realizado.");
            } else {
                System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private void menuCliente(Usuario usuario) {
        Carrinho carrinho = new Carrinho();
        int opcao;

        do {
            mostrarCabecalho("LOJA - CLIENTE");
            System.out.println("1 - Buscar produto");
            System.out.println("2 - Adicionar produto ao carrinho");
            System.out.println("3 - Remover produto do carrinho");
            System.out.println("4 - Visualizar carrinho");
            System.out.println("5 - Confirmar compra/reserva");
            System.out.println("0 - Fazer logout");
            opcao = input.lerInteiro("Escolha uma opcao: ");

            if (opcao == 1) {
                buscarProduto();
            } else if (opcao == 2) {
                adicionarAoCarrinho(carrinho);
            } else if (opcao == 3) {
                removerDoCarrinho(carrinho);
            } else if (opcao == 4) {
                mostrarCarrinho(carrinho);
            } else if (opcao == 5) {
                confirmarCompra(usuario, carrinho);
            } else if (opcao == 0) {
                System.out.println("Logout realizado.");
            } else {
                System.out.println("Opcao invalida.");
            }
        } while (opcao != 0);
    }

    private void cadastrarProduto() {
        mostrarCabecalho("CADASTRO DE PRODUTO");

        try {
            String nome = input.lerTextoObrigatorio("Nome: ");
            String descricao = input.lerTextoObrigatorio("Descricao: ");
            BigDecimal preco = input.lerDecimalPositivo("Preco: ");
            int estoque = input.lerInteiroMinimo("Estoque: ", 0);
            String img = input.lerTexto("Imagem/caminho opcional: ");

            produtoService.cadastrarProduto(nome, descricao, preco, estoque, img);
            System.out.println("Produto cadastrado com sucesso!");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro de validacao: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro ao salvar produto no banco: " + e.getMessage());
        }
    }

    private void buscarProduto() {
        mostrarCabecalho("BUSCAR PRODUTO");

        try {
            String termo = input.lerTextoObrigatorio("Digite o nome ou ID do produto: ");
            List<Produto> produtos = produtoService.buscarPorNomeOuId(termo);

            if (produtos.isEmpty()) {
                System.out.println("Produto Nao Encontrado");
            } else {
                imprimirProdutos(produtos);
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Erro de validacao: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro ao buscar produto no banco: " + e.getMessage());
        }
    }

    private void removerProduto() {
        mostrarCabecalho("REMOVER PRODUTO");

        try {
            int id = input.lerInteiro("ID do produto que deseja remover: ");
            Produto produto = produtoService.buscarPorId(id);

            if (produto == null) {
                System.out.println("Produto Nao Encontrado");
                return;
            }

            imprimirProduto(produto);
            boolean confirma = input.confirmar("Tem certeza que deseja remover este produto?");

            if (!confirma) {
                System.out.println("Remocao cancelada.");
                return;
            }

            boolean removido = produtoService.removerProduto(id);
            if (removido) {
                System.out.println("Produto removido com sucesso!");
            } else {
                System.out.println("Produto nao foi removido.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao remover produto: " + e.getMessage());
            System.out.println("Observacao: se o produto ja estiver em um pedido, o banco pode impedir a exclusao por causa da chave estrangeira.");
        }
    }

    private void atualizarProduto() {
        mostrarCabecalho("ATUALIZAR PRODUTO");

        try {
            int id = input.lerInteiro("ID do produto que deseja atualizar: ");
            Produto produto = produtoService.buscarPorId(id);

            if (produto == null) {
                System.out.println("Produto Nao Encontrado");
                return;
            }

            System.out.println("Produto atual:");
            imprimirProduto(produto);
            System.out.println("Digite os novos dados. Se quiser manter algum dado, pressione ENTER.");

            String nome = input.lerTexto("Novo nome [" + produto.getNome() + "]: ");
            String descricao = input.lerTexto("Nova descricao [" + produto.getDescricao() + "]: ");
            String precoTexto = input.lerTexto("Novo preco [" + produto.getPreco() + "]: ");
            String estoqueTexto = input.lerTexto("Novo estoque [" + produto.getEstoque() + "]: ");
            String img = input.lerTexto("Nova imagem/caminho [" + produto.getImg() + "]: ");

            if (!nome.trim().isEmpty()) {
                produto.setNome(nome.trim());
            }
            if (!descricao.trim().isEmpty()) {
                produto.setDescricao(descricao.trim());
            }
            if (!precoTexto.trim().isEmpty()) {
                produto.setPreco(new BigDecimal(precoTexto.replace(".", "").replace(",", ".")));
            }
            if (!estoqueTexto.trim().isEmpty()) {
                produto.setEstoque(Integer.parseInt(estoqueTexto.trim()));
            }
            if (!img.trim().isEmpty()) {
                produto.setImg(img.trim());
            }

            boolean atualizado = produtoService.atualizarProduto(produto);
            if (atualizado) {
                System.out.println("Produto atualizado com sucesso!");
            } else {
                System.out.println("Produto nao foi atualizado.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Preco ou estoque informado em formato invalido.");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro de validacao: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar produto: " + e.getMessage());
        }
    }

    private void listarProdutos() {
        mostrarCabecalho("LISTA DE PRODUTOS");

        try {
            List<Produto> produtos = produtoService.listarTodos();
            if (produtos.isEmpty()) {
                System.out.println("Nenhum produto cadastrado.");
            } else {
                imprimirProdutos(produtos);
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar produtos: " + e.getMessage());
        }
    }

    private void listarUsuarios() {
        mostrarCabecalho("USUARIOS DO SISTEMA");

        try {
            List<Usuario> usuarios = usuarioService.listarUsuariosComuns();
            if (usuarios.isEmpty()) {
                System.out.println("Nenhum usuario comum cadastrado.");
                return;
            }

            for (Usuario usuario : usuarios) {
                System.out.println("ID: " + usuario.getId() +
                        " | Nome: " + usuario.getNomeCompleto() +
                        " | Login: " + usuario.getLogin());
            }
        } catch (SQLException e) {
            System.out.println("Erro ao listar usuarios: " + e.getMessage());
        }
    }

    private void removerUsuarioComum() {
        mostrarCabecalho("REMOVER USUARIO COMUM");

        try {
            listarUsuarios();
            int id = input.lerInteiro("ID do usuario comum que deseja remover: ");
            boolean confirma = input.confirmar("Tem certeza que deseja remover este usuario?");

            if (!confirma) {
                System.out.println("Remocao cancelada.");
                return;
            }

            boolean removido = usuarioService.removerUsuarioComum(id);
            if (removido) {
                System.out.println("Usuario removido com sucesso!");
            } else {
                System.out.println("Usuario nao encontrado ou nao pode ser removido.");
            }
        } catch (SQLException e) {
            System.out.println("Erro ao remover usuario: " + e.getMessage());
            System.out.println("Observacao: se o usuario ja tiver pedidos, o banco pode impedir a exclusao por causa da chave estrangeira.");
        }
    }

    private void adicionarAoCarrinho(Carrinho carrinho) {
        mostrarCabecalho("ADICIONAR AO CARRINHO");

        try {
            int id = input.lerInteiro("ID do produto: ");
            Produto produto = produtoService.buscarPorId(id);

            if (produto == null) {
                System.out.println("Produto Nao Encontrado");
                return;
            }

            imprimirProduto(produto);

            if (produto.getEstoque() <= 0) {
                System.out.println("Produto sem estoque.");
                return;
            }

            int quantidade = input.lerInteiroMinimo("Quantidade: ", 1);
            int quantidadeJaNoCarrinho = carrinho.getQuantidadeProduto(produto.getId());
            int quantidadeTotalDesejada = quantidadeJaNoCarrinho + quantidade;

            if (quantidadeTotalDesejada > produto.getEstoque()) {
                System.out.println("Nao foi possivel adicionar. Estoque disponivel: " + produto.getEstoque());
                System.out.println("Quantidade ja no carrinho: " + quantidadeJaNoCarrinho);
                return;
            }

            carrinho.adicionarProduto(produto, quantidade);
            System.out.println("Produto adicionado ao carrinho!");
        } catch (SQLException e) {
            System.out.println("Erro ao consultar produto: " + e.getMessage());
        }
    }

    private void removerDoCarrinho(Carrinho carrinho) {
        mostrarCabecalho("REMOVER DO CARRINHO");

        if (carrinho.estaVazio()) {
            System.out.println("Carrinho vazio.");
            return;
        }

        mostrarCarrinho(carrinho);
        int id = input.lerInteiro("ID do produto que deseja remover do carrinho: ");
        boolean removido = carrinho.removerProduto(id);

        if (removido) {
            System.out.println("Produto removido do carrinho.");
        } else {
            System.out.println("Este produto nao esta no carrinho.");
        }
    }

    private void confirmarCompra(Usuario usuario, Carrinho carrinho) {
        mostrarCabecalho("CONFIRMAR COMPRA/RESERVA");

        if (carrinho.estaVazio()) {
            System.out.println("Carrinho vazio. Adicione produtos antes de confirmar.");
            return;
        }

        mostrarCarrinho(carrinho);
        boolean confirma = input.confirmar("Confirmar esta compra/reserva sem pagamento?");

        if (!confirma) {
            System.out.println("Compra cancelada. O carrinho continua com os produtos.");
            return;
        }

        try {
            int pedidoId = pedidoService.confirmarCompra(usuario, carrinho);
            carrinho.limpar();
            System.out.println("Compra/reserva confirmada com sucesso!");
            System.out.println("Numero do pedido: " + pedidoId);
            System.out.println("Estoque atualizado no banco de dados.");
        } catch (IllegalArgumentException e) {
            System.out.println("Erro de validacao: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Erro ao confirmar compra no banco: " + e.getMessage());
        }
    }

    private void mostrarCarrinho(Carrinho carrinho) {
        mostrarCabecalho("CARRINHO DE COMPRAS");

        if (carrinho.estaVazio()) {
            System.out.println("Carrinho vazio.");
            return;
        }

        for (CarrinhoItem item : carrinho.getItens()) {
            Produto produto = item.getProduto();
            System.out.println("ID: " + produto.getId() +
                    " | Produto: " + produto.getNome() +
                    " | Qtd: " + item.getQuantidade() +
                    " | Preco: " + FormatUtil.moeda(produto.getPreco()) +
                    " | Subtotal: " + FormatUtil.moeda(item.getSubtotal()));
        }

        System.out.println("----------------------------------------");
        System.out.println("TOTAL DO CARRINHO: " + FormatUtil.moeda(carrinho.getTotal()));
    }

    private void imprimirProdutos(List<Produto> produtos) {
        for (Produto produto : produtos) {
            imprimirProduto(produto);
        }
    }

    private void imprimirProduto(Produto produto) {
        System.out.println("ID: " + produto.getId() +
                " | Nome: " + produto.getNome() +
                " | Descricao: " + produto.getDescricao() +
                " | Preco: " + FormatUtil.moeda(produto.getPreco()) +
                " | Estoque: " + produto.getEstoque());
    }

    private void mostrarCabecalho(String titulo) {
        System.out.println();
        System.out.println("========================================");
        System.out.println("        " + titulo);
        System.out.println("========================================");
    }
}
