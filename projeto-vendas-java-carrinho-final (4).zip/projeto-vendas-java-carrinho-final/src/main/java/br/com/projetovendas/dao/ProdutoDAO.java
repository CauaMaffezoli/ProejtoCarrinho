package br.com.projetovendas.dao;

import br.com.projetovendas.config.ConnectionFactory;
import br.com.projetovendas.model.Produto;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {

    public void inserir(Produto produto) throws SQLException {
        String sql = "INSERT INTO produtos (nome, descricao, preco, estoque, img) VALUES (?, ?, ?, ?, ?)";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getDescricao());
            stmt.setBigDecimal(3, produto.getPreco());
            stmt.setInt(4, produto.getEstoque());
            stmt.setString(5, produto.getImg());
            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                produto.setId(rs.getInt(1));
            }
            rs.close();
        } finally {
            fechar(stmt, conn);
        }
    }

    public boolean atualizar(Produto produto) throws SQLException {
        String sql = "UPDATE produtos SET nome = ?, descricao = ?, preco = ?, estoque = ?, img = ? WHERE id = ?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getDescricao());
            stmt.setBigDecimal(3, produto.getPreco());
            stmt.setInt(4, produto.getEstoque());
            stmt.setString(5, produto.getImg());
            stmt.setInt(6, produto.getId());
            return stmt.executeUpdate() > 0;
        } finally {
            fechar(stmt, conn);
        }
    }

    public boolean remover(int id) throws SQLException {
        String sql = "DELETE FROM produtos WHERE id = ?";

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } finally {
            fechar(stmt, conn);
        }
    }

    public Produto buscarPorId(int id) throws SQLException {
        Connection conn = null;
        try {
            conn = ConnectionFactory.getConnection();
            return buscarPorId(conn, id);
        } finally {
            if (conn != null) {
                conn.close();
            }
        }
    }

    public Produto buscarPorId(Connection conn, int id) throws SQLException {
        String sql = "SELECT id, nome, descricao, preco, estoque, img FROM produtos WHERE id = ?";

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {
                return montarProduto(rs);
            }
            return null;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public Produto buscarPorIdComBloqueio(Connection conn, int id) throws SQLException {
        String sql = "SELECT id, nome, descricao, preco, estoque, img FROM produtos WHERE id = ? FOR UPDATE";

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();

            if (rs.next()) {
                return montarProduto(rs);
            }
            return null;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public List<Produto> buscarPorNome(String nome) throws SQLException {
        String sql = "SELECT id, nome, descricao, preco, estoque, img FROM produtos WHERE LOWER(nome) LIKE LOWER(?) ORDER BY nome";
        List<Produto> produtos = new ArrayList<Produto>();

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + nome + "%");
            rs = stmt.executeQuery();

            while (rs.next()) {
                produtos.add(montarProduto(rs));
            }
            return produtos;
        } finally {
            fechar(rs, stmt, conn);
        }
    }

    public List<Produto> buscarPorNomeOuId(String termo) throws SQLException {
        List<Produto> produtos = new ArrayList<Produto>();

        Integer id = tentarConverterParaInteiro(termo);
        if (id != null) {
            Produto produto = buscarPorId(id);
            if (produto != null) {
                produtos.add(produto);
            }
            return produtos;
        }

        return buscarPorNome(termo);
    }

    public List<Produto> listarTodos() throws SQLException {
        String sql = "SELECT id, nome, descricao, preco, estoque, img FROM produtos ORDER BY id";
        List<Produto> produtos = new ArrayList<Produto>();

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                produtos.add(montarProduto(rs));
            }
            return produtos;
        } finally {
            fechar(rs, stmt, conn);
        }
    }

    public boolean baixarEstoque(Connection conn, int produtoId, int quantidade) throws SQLException {
        String sql = "UPDATE produtos SET estoque = estoque - ? WHERE id = ? AND estoque >= ?";

        PreparedStatement stmt = null;

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, quantidade);
            stmt.setInt(2, produtoId);
            stmt.setInt(3, quantidade);
            return stmt.executeUpdate() > 0;
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    private Produto montarProduto(ResultSet rs) throws SQLException {
        Produto produto = new Produto();
        produto.setId(rs.getInt("id"));
        produto.setNome(rs.getString("nome"));
        produto.setDescricao(rs.getString("descricao"));
        produto.setPreco(rs.getBigDecimal("preco"));
        produto.setEstoque(rs.getInt("estoque"));
        produto.setImg(rs.getString("img"));
        return produto;
    }

    private Integer tentarConverterParaInteiro(String termo) {
        try {
            return Integer.parseInt(termo.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void fechar(Statement stmt, Connection conn) throws SQLException {
        if (stmt != null) {
            stmt.close();
        }
        if (conn != null) {
            conn.close();
        }
    }

    private void fechar(ResultSet rs, Statement stmt, Connection conn) throws SQLException {
        if (rs != null) {
            rs.close();
        }
        fechar(stmt, conn);
    }
}
