package br.com.projetovendas.model;

import java.math.BigDecimal;

public class PedidoItem {
    private int pedidoId;
    private Produto produto;
    private int quantidade;
    private BigDecimal precoUnitario;

    public PedidoItem() {
    }

    public PedidoItem(int pedidoId, Produto produto, int quantidade, BigDecimal precoUnitario) {
        this.pedidoId = pedidoId;
        this.produto = produto;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
    }

    public int getPedidoId() {
        return pedidoId;
    }

    public void setPedidoId(int pedidoId) {
        this.pedidoId = pedidoId;
    }

    public Produto getProduto() {
        return produto;
    }

    public void setProduto(Produto produto) {
        this.produto = produto;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public BigDecimal getPrecoUnitario() {
        return precoUnitario;
    }

    public void setPrecoUnitario(BigDecimal precoUnitario) {
        this.precoUnitario = precoUnitario;
    }

    public BigDecimal getSubtotal() {
        return precoUnitario.multiply(new BigDecimal(quantidade));
    }
}
