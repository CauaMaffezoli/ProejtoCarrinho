package br.com.projetovendas.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {

    /*
     * CONFIGURACAO PADRAO PARA XAMPP / MYSQL / PHPMYADMIN
     *
     * No XAMPP, normalmente o usuario eh root e a senha fica vazia.
     * O banco precisa se chamar projeto_vendas, conforme o script SQL.
     */
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/projeto_vendas?useSSL=false&serverTimezone=America/Sao_Paulo&allowPublicKeyRetrieval=true";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    /*
     * CASO A PROFESSORA USE POSTGRESQL / PGADMIN, comente as linhas acima
     * e descomente estas linhas abaixo, ajustando usuario e senha:
     *
     * private static final String DRIVER = "org.postgresql.Driver";
     * private static final String URL = "jdbc:postgresql://localhost:5432/projeto_vendas";
     * private static final String USER = "postgres";
     * private static final String PASSWORD = "sua_senha";
     */

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName(DRIVER);
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new SQLException("Driver JDBC nao encontrado. Verifique se a dependencia esta no projeto.", e);
        }
    }
}
