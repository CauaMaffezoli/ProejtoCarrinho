package br.com.projetovendas.app;

import br.com.projetovendas.view.LoginView;
import javafx.application.Application;

/**
 * Ponto de entrada da aplicação.
 * Delega a inicialização para o JavaFX via LoginView.
 */
public class Main {
    public static void main(String[] args) {
        Application.launch(LoginView.class, args);
    }
}
