package br.com.projetovendas.view;

import br.com.projetovendas.service.UsuarioService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.sql.SQLException;

/**
 * Tela de cadastro de novo usuário.
 * Acessada a partir da tela de login.
 */
public class CadastroView {

    private final Stage stage;
    private final UsuarioService usuarioService = new UsuarioService();

    public CadastroView(Stage stage) {
        this.stage = stage;
    }

    /**
     * Exibe a tela de cadastro na janela principal.
     */
    public void show() {
        Label titulo = new Label("Cadastro de Usuário");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 20));

        TextField campoNome      = new TextField(); campoNome.setPromptText("Nome");
        TextField campoSobrenome = new TextField(); campoSobrenome.setPromptText("Sobrenome");
        TextField campoLogin     = new TextField(); campoLogin.setPromptText("Login");
        PasswordField campoSenha    = new PasswordField(); campoSenha.setPromptText("Senha (mín. 8 caracteres)");
        PasswordField campoConfirma = new PasswordField(); campoConfirma.setPromptText("Confirme a senha");

        for (Control c : new Control[]{campoNome, campoSobrenome, campoLogin, campoSenha, campoConfirma}) {
            ((Region) c).setPrefHeight(36);
        }

        Label lblErro = new Label();
        lblErro.setStyle("-fx-text-fill: #c0392b;");
        lblErro.setWrapText(true);

        Label lblSucesso = new Label();
        lblSucesso.setStyle("-fx-text-fill: #27ae60;");

        Button btnCadastrar = new Button("Cadastrar");
        btnCadastrar.setPrefWidth(Double.MAX_VALUE);
        btnCadastrar.setPrefHeight(38);
        btnCadastrar.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-size: 14; -fx-background-radius: 6;");

        btnCadastrar.setOnAction(e -> {
            lblErro.setText("");
            lblSucesso.setText("");
            try {
                usuarioService.cadastrarUsuario(
                        campoNome.getText(),
                        campoSobrenome.getText(),
                        campoLogin.getText(),
                        campoSenha.getText(),
                        campoConfirma.getText()
                );
                lblSucesso.setText("Usuário cadastrado com sucesso! Faça login.");
                campoNome.clear(); campoSobrenome.clear();
                campoLogin.clear(); campoSenha.clear(); campoConfirma.clear();
            } catch (IllegalArgumentException ex) {
                lblErro.setText(ex.getMessage());
            } catch (SQLException ex) {
                lblErro.setText("Erro no banco: " + ex.getMessage());
            }
        });

        Button btnVoltar = new Button("← Voltar ao Login");
        btnVoltar.setStyle("-fx-background-color: transparent; -fx-text-fill: #2980b9; -fx-underline: true;");
        btnVoltar.setOnAction(e -> {
            try { new LoginView().start(stage); } catch (Exception ex) { ex.printStackTrace(); }
        });

        VBox form = new VBox(10,
                titulo, new Separator(),
                new Label("Nome:"), campoNome,
                new Label("Sobrenome:"), campoSobrenome,
                new Label("Login:"), campoLogin,
                new Label("Senha:"), campoSenha,
                new Label("Confirmar senha:"), campoConfirma,
                lblErro, lblSucesso,
                btnCadastrar, btnVoltar
        );
        form.setPadding(new Insets(30));
        form.setMaxWidth(380);

        StackPane root = new StackPane(form);
        root.setStyle("-fx-background-color: #f4f6f8;");
        StackPane.setAlignment(form, Pos.CENTER);

        stage.setScene(new Scene(root, 440, 560));
        stage.setTitle("Cadastro de Usuário");
    }
}
