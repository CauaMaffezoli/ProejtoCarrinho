package br.com.projetovendas.service;

import br.com.projetovendas.dao.UsuarioDAO;
import br.com.projetovendas.model.TipoUsuario;
import br.com.projetovendas.model.Usuario;

import java.sql.SQLException;
import java.util.List;

public class UsuarioService {
    private UsuarioDAO usuarioDAO;

    public UsuarioService() {
        this.usuarioDAO = new UsuarioDAO();
    }

    public void cadastrarUsuario(String nome, String sobrenome, String login, String senha, String confirmacaoSenha) throws SQLException {
        validarCampoObrigatorio(nome, "Nome");
        validarCampoObrigatorio(sobrenome, "Sobrenome");
        validarCampoObrigatorio(login, "Login");
        validarCampoObrigatorio(senha, "Senha");
        validarCampoObrigatorio(confirmacaoSenha, "Confirmacao de senha");

        if (senha.length() < 8) {
            throw new IllegalArgumentException("A senha precisa ter no minimo 8 caracteres.");
        }

        if (!senha.equals(confirmacaoSenha)) {
            throw new IllegalArgumentException("A senha e a confirmacao de senha nao conferem.");
        }

        Usuario usuarioExistente = usuarioDAO.buscarPorLogin(login);
        if (usuarioExistente != null) {
            throw new IllegalArgumentException("Ja existe um usuario cadastrado com esse login.");
        }

        Usuario usuario = new Usuario();
        usuario.setNome(nome.trim());
        usuario.setSobrenome(sobrenome.trim());
        usuario.setLogin(login.trim());
        usuario.setSenha(senha);
        usuario.setTipo(TipoUsuario.USUARIO);

        usuarioDAO.inserir(usuario);
    }

    public Usuario autenticar(String login, String senha, TipoUsuario tipo) throws SQLException {
        validarCampoObrigatorio(login, "Login");
        validarCampoObrigatorio(senha, "Senha");
        return usuarioDAO.autenticar(login, senha, tipo);
    }

    public List<Usuario> listarUsuariosComuns() throws SQLException {
        return usuarioDAO.listarUsuariosComuns();
    }

    public boolean removerUsuarioComum(int id) throws SQLException {
        return usuarioDAO.removerUsuarioComum(id);
    }

    private void validarCampoObrigatorio(String valor, String nomeCampo) {
        if (valor == null || valor.trim().isEmpty()) {
            throw new IllegalArgumentException(nomeCampo + " eh obrigatorio.");
        }
    }
}
