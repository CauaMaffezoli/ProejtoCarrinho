package br.com.projetovendas.dao;

import br.com.projetovendas.model.Pedido;
import br.com.projetovendas.model.PedidoItem;
import br.com.projetovendas.model.Produto;
import br.com.projetovendas.model.Usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    public int inserirPedido(Connection conn, Pedido pedido) throws SQLException {
        String sql = "INSERT INTO pedidos (usuario_id, data_pedido, status, total) VALUES (?, ?, ?, ?)";

        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setInt(1, pedido.getUsuario().getId());
            stmt.setTimestamp(2, Timestamp.valueOf(pedido.getDataPedido()));
            stmt.setString(3, pedido.getStatus());
            stmt.setBigDecimal(4, pedido.getTotal());
            stmt.executeUpdate();

            rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            }

            throw new SQLException("Nao foi possivel obter o ID do pedido gerado.");
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public void inserirItem(Connection conn, int pedidoId, PedidoItem item) throws SQLException {
        String sql = "INSERT INTO pedido_produto (pedido_id, produto_id, quantidade, preco_unitario) VALUES (?, ?, ?, ?)";

        PreparedStatement stmt = null;

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, pedidoId);
            stmt.setInt(2, item.getProduto().getId());
            stmt.setInt(3, item.getQuantidade());
            stmt.setBigDecimal(4, item.getPrecoUnitario());
            stmt.executeUpdate();
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
    }

    public List<Pedido> listarPedidosPorUsuario(int usuarioId) throws SQLException {
        String sql = "SELECT id, usuario_id, data_pedido, status, total FROM pedidos WHERE usuario_id = ? ORDER BY data_pedido DESC";
        List<Pedido> pedidos = new ArrayList<Pedido>();

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = br.com.projetovendas.config.ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, usuarioId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Pedido pedido = new Pedido();
                Usuario usuario = new Usuario();
                usuario.setId(rs.getInt("usuario_id"));

                pedido.setId(rs.getInt("id"));
                pedido.setUsuario(usuario);
                pedido.setDataPedido(rs.getTimestamp("data_pedido").toLocalDateTime());
                pedido.setStatus(rs.getString("status"));
                pedido.setTotal(rs.getBigDecimal("total"));
                pedidos.add(pedido);
            }

            return pedidos;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }

    public List<PedidoItem> listarItensPedido(int pedidoId) throws SQLException {
        String sql = "SELECT pp.pedido_id, pp.quantidade, pp.preco_unitario, " +
                "p.id AS produto_id, p.nome, p.descricao, p.preco, p.estoque, p.img " +
                "FROM pedido_produto pp " +
                "INNER JOIN produtos p ON p.id = pp.produto_id " +
                "WHERE pp.pedido_id = ?";

        List<PedidoItem> itens = new ArrayList<PedidoItem>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = br.com.projetovendas.config.ConnectionFactory.getConnection();
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, pedidoId);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("produto_id"));
                produto.setNome(rs.getString("nome"));
                produto.setDescricao(rs.getString("descricao"));
                produto.setPreco(rs.getBigDecimal("preco"));
                produto.setEstoque(rs.getInt("estoque"));
                produto.setImg(rs.getString("img"));

                PedidoItem item = new PedidoItem();
                item.setPedidoId(rs.getInt("pedido_id"));
                item.setProduto(produto);
                item.setQuantidade(rs.getInt("quantidade"));
                item.setPrecoUnitario(rs.getBigDecimal("preco_unitario"));
                itens.add(item);
            }

            return itens;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (stmt != null) {
                stmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        }
    }
}
