package br.com.projetovendas.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Carrinho {
    private Map<Integer, CarrinhoItem> itens;

    public Carrinho() {
        this.itens = new LinkedHashMap<Integer, CarrinhoItem>();
    }

    public void adicionarProduto(Produto produto, int quantidade) {
        CarrinhoItem itemExistente = itens.get(produto.getId());

        if (itemExistente == null) {
            itens.put(produto.getId(), new CarrinhoItem(produto, quantidade));
        } else {
            itemExistente.setQuantidade(itemExistente.getQuantidade() + quantidade);
        }
    }

    public boolean removerProduto(int produtoId) {
        return itens.remove(produtoId) != null;
    }

    public int getQuantidadeProduto(int produtoId) {
        CarrinhoItem item = itens.get(produtoId);
        if (item == null) {
            return 0;
        }
        return item.getQuantidade();
    }

    public List<CarrinhoItem> getItens() {
        return new ArrayList<CarrinhoItem>(itens.values());
    }

    public boolean estaVazio() {
        return itens.isEmpty();
    }

    public BigDecimal getTotal() {
        BigDecimal total = BigDecimal.ZERO;
        for (CarrinhoItem item : itens.values()) {
            total = total.add(item.getSubtotal());
        }
        return total;
    }

    public void limpar() {
        itens.clear();
    }
}
