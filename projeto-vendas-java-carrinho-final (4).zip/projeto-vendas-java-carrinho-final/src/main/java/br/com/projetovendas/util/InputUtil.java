package br.com.projetovendas.util;

import java.math.BigDecimal;
import java.util.Scanner;

public class InputUtil {
    private Scanner scanner;

    public InputUtil(Scanner scanner) {
        this.scanner = scanner;
    }

    public String lerTexto(String mensagem) {
        System.out.print(mensagem);
        return scanner.nextLine();
    }

    public String lerTextoObrigatorio(String mensagem) {
        while (true) {
            String valor = lerTexto(mensagem);
            if (valor != null && !valor.trim().isEmpty()) {
                return valor.trim();
            }
            System.out.println("Este campo eh obrigatorio. Tente novamente.");
        }
    }

    public int lerInteiro(String mensagem) {
        while (true) {
            try {
                String valor = lerTexto(mensagem);
                return Integer.parseInt(valor.trim());
            } catch (NumberFormatException e) {
                System.out.println("Digite um numero inteiro valido.");
            }
        }
    }

    public int lerInteiroMinimo(String mensagem, int minimo) {
        while (true) {
            int valor = lerInteiro(mensagem);
            if (valor >= minimo) {
                return valor;
            }
            System.out.println("Digite um valor maior ou igual a " + minimo + ".");
        }
    }

    public BigDecimal lerDecimal(String mensagem) {
        while (true) {
            try {
                String valor = lerTexto(mensagem);
                valor = valor.replace(".", "").replace(",", ".");
                return new BigDecimal(valor.trim());
            } catch (Exception e) {
                System.out.println("Digite um valor decimal valido. Exemplo: 12,90");
            }
        }
    }

    public BigDecimal lerDecimalPositivo(String mensagem) {
        while (true) {
            BigDecimal valor = lerDecimal(mensagem);
            if (valor.compareTo(BigDecimal.ZERO) > 0) {
                return valor;
            }
            System.out.println("O valor precisa ser maior que zero.");
        }
    }

    public boolean confirmar(String mensagem) {
        while (true) {
            String resposta = lerTexto(mensagem + " (S/N): ");
            if (resposta.equalsIgnoreCase("S")) {
                return true;
            }
            if (resposta.equalsIgnoreCase("N")) {
                return false;
            }
            System.out.println("Digite S para sim ou N para nao.");
        }
    }
}
