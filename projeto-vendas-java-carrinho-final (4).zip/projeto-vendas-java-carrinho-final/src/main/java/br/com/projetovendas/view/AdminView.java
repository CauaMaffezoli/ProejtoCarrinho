package br.com.projetovendas.view;

import br.com.projetovendas.model.Produto;
import br.com.projetovendas.model.Usuario;
import br.com.projetovendas.service.ProdutoService;
import br.com.projetovendas.service.UsuarioService;
import javafx.application.Application;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/**
 * Tela administrativa do sistema.
 * Permite gerenciar produtos e usuários comuns.
 * Implementa as funcionalidades: cadastrar, buscar, remover e atualizar produto.
 */
public class AdminView extends Application {

    private final Usuario admin;
    private final ProdutoService produtoService = new ProdutoService();
    private final UsuarioService usuarioService = new UsuarioService();

    private TableView<Produto> tabelaProdutos;
    private ObservableList<Produto> listaProdutos;
    private TextField campoBusca;
    private Label lblStatus;

    public AdminView(Usuario admin) {
        this.admin = admin;
    }

    @Override
    public void start(Stage stage) {
        stage.setTitle("Área Administrativa - " + admin.getNomeCompleto());

        // Cabeçalho
        Label titulo = new Label("Área Administrativa");
        titulo.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        Label lblUsuario = new Label("Logado como: " + admin.getNomeCompleto());
        lblUsuario.setStyle("-fx-text-fill: #555;");

        Button btnLogout = new Button("Logout");
        btnLogout.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-background-radius: 5;");
        btnLogout.setOnAction(e -> {
            try { new LoginView().start(stage); } catch (Exception ex) { ex.printStackTrace(); }
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox cabecalho = new HBox(10, titulo, spacer, lblUsuario, btnLogout);
        cabecalho.setAlignment(Pos.CENTER_LEFT);
        cabecalho.setPadding(new Insets(10, 16, 10, 16));
        cabecalho.setStyle("-fx-background-color: #2c3e50;");
        titulo.setStyle("-fx-text-fill: white;");
        lblUsuario.setStyle("-fx-text-fill: #bdc3c7;");

        // Abas
        TabPane abas = new TabPane();
        abas.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        abas.getTabs().addAll(
                criarAbaProdutos(),
                criarAbaUsuarios()
        );

        // Status bar
        lblStatus = new Label("Pronto.");
        lblStatus.setStyle("-fx-text-fill: #555; -fx-padding: 4 12;");

        VBox root = new VBox(cabecalho, abas, lblStatus);
        VBox.setVgrow(abas, Priority.ALWAYS);

        Scene scene = new Scene(root, 900, 620);
        stage.setScene(scene);
        stage.show();

        carregarProdutos();
    }

    // ─── Aba Produtos ───────────────────────────────────────────────────────────

    private Tab criarAbaProdutos() {
        Tab tab = new Tab("Produtos");

        // Barra de busca
        campoBusca = new TextField();
        campoBusca.setPromptText("Buscar por nome ou ID...");
        campoBusca.setPrefWidth(260);

        Button btnBuscar = botao("Buscar", "#2980b9");
        btnBuscar.setOnAction(e -> buscarProduto());
        campoBusca.setOnAction(e -> buscarProduto());

        Button btnListarTodos = botao("Listar Todos", "#7f8c8d");
        btnListarTodos.setOnAction(e -> carregarProdutos());

        HBox barraBusca = new HBox(8, campoBusca, btnBuscar, btnListarTodos);
        barraBusca.setAlignment(Pos.CENTER_LEFT);

        // Tabela
        tabelaProdutos = new TableView<>();
        listaProdutos  = FXCollections.observableArrayList();
        tabelaProdutos.setItems(listaProdutos);
        tabelaProdutos.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Produto, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colId.setMaxWidth(60);

        TableColumn<Produto, String> colNome = new TableColumn<>("Nome");
        colNome.setCellValueFactory(new PropertyValueFactory<>("nome"));

        TableColumn<Produto, String> colDesc = new TableColumn<>("Descrição");
        colDesc.setCellValueFactory(new PropertyValueFactory<>("descricao"));

        TableColumn<Produto, BigDecimal> colPreco = new TableColumn<>("Preço");
        colPreco.setCellValueFactory(new PropertyValueFactory<>("preco"));
        colPreco.setMaxWidth(100);

        TableColumn<Produto, Integer> colEstoque = new TableColumn<>("Estoque");
        colEstoque.setCellValueFactory(new PropertyValueFactory<>("estoque"));
        colEstoque.setMaxWidth(80);

        tabelaProdutos.getColumns().addAll(colId, colNome, colDesc, colPreco, colEstoque);

        // Botões de ação
        Button btnNovo    = botao("+ Novo Produto", "#27ae60");
        Button btnEditar  = botao("✎ Editar",       "#f39c12");
        Button btnRemover = botao("✕ Remover",       "#e74c3c");

        btnNovo.setOnAction(e -> abrirFormProduto(null));
        btnEditar.setOnAction(e -> {
            Produto selecionado = tabelaProdutos.getSelectionModel().getSelectedItem();
            if (selecionado == null) { setStatus("Selecione um produto para editar."); return; }
            abrirFormProduto(selecionado);
        });
        btnRemover.setOnAction(e -> removerProdutoSelecionado());

        HBox acoes = new HBox(8, btnNovo, btnEditar, btnRemover);

        VBox conteudo = new VBox(10, barraBusca, tabelaProdutos, acoes);
        conteudo.setPadding(new Insets(14));
        VBox.setVgrow(tabelaProdutos, Priority.ALWAYS);

        tab.setContent(conteudo);
        return tab;
    }

    private void carregarProdutos() {
        try {
            List<Produto> lista = produtoService.listarTodos();
            listaProdutos.setAll(lista);
            setStatus("Total: " + lista.size() + " produto(s).");
        } catch (SQLException e) {
            alertaErro("Erro ao listar produtos: " + e.getMessage());
        }
    }

    private void buscarProduto() {
        String termo = campoBusca.getText().trim();
        if (termo.isEmpty()) { carregarProdutos(); return; }
        try {
            List<Produto> resultado = produtoService.buscarPorNomeOuId(termo);
            listaProdutos.setAll(resultado);
            setStatus(resultado.isEmpty() ? "Nenhum produto encontrado." : resultado.size() + " produto(s) encontrado(s).");
        } catch (Exception e) {
            alertaErro("Erro na busca: " + e.getMessage());
        }
    }

    private void removerProdutoSelecionado() {
        Produto p = tabelaProdutos.getSelectionModel().getSelectedItem();
        if (p == null) { setStatus("Selecione um produto para remover."); return; }

        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Remover \"" + p.getNome() + "\"?", ButtonType.YES, ButtonType.NO);
        confirm.setHeaderText("Confirmar remoção");
        Optional<ButtonType> resp = confirm.showAndWait();

        if (resp.isPresent() && resp.get() == ButtonType.YES) {
            try {
                produtoService.removerProduto(p.getId());
                setStatus("Produto removido com sucesso.");
                carregarProdutos();
            } catch (SQLException e) {
                alertaErro("Erro ao remover: " + e.getMessage() +
                        "\nObservação: produtos vinculados a pedidos não podem ser removidos.");
            }
        }
    }

    /**
     * Abre formulário para cadastrar (produto == null) ou editar um produto existente.
     */
    private void abrirFormProduto(Produto produto) {
        Stage dialog = new Stage();
        dialog.setTitle(produto == null ? "Novo Produto" : "Editar Produto");

        TextField fNome    = campo(produto != null ? produto.getNome() : "", "Nome");
        TextField fDesc    = campo(produto != null ? produto.getDescricao() : "", "Descrição");
        TextField fPreco   = campo(produto != null ? produto.getPreco().toPlainString() : "", "Ex: 29.90");
        TextField fEstoque = campo(produto != null ? String.valueOf(produto.getEstoque()) : "0", "Estoque");
        TextField fImg     = campo(produto != null ? produto.getImg() : "", "Caminho da imagem (opcional)");

        Label lblErro = new Label(); lblErro.setStyle("-fx-text-fill: #c0392b;"); lblErro.setWrapText(true);

        Button btnSalvar = botao(produto == null ? "Cadastrar" : "Salvar", "#27ae60");
        btnSalvar.setOnAction(e -> {
            lblErro.setText("");
            try {
                String nome    = fNome.getText().trim();
                String desc    = fDesc.getText().trim();
                BigDecimal preco = new BigDecimal(fPreco.getText().trim().replace(",", "."));
                int estoque    = Integer.parseInt(fEstoque.getText().trim());
                String img     = fImg.getText().trim();

                if (produto == null) {
                    produtoService.cadastrarProduto(nome, desc, preco, estoque, img);
                    setStatus("Produto cadastrado com sucesso!");
                } else {
                    produto.setNome(nome); produto.setDescricao(desc);
                    produto.setPreco(preco); produto.setEstoque(estoque); produto.setImg(img);
                    produtoService.atualizarProduto(produto);
                    setStatus("Produto atualizado com sucesso!");
                }
                carregarProdutos();
                dialog.close();
            } catch (NumberFormatException ex) {
                lblErro.setText("Preço ou estoque com formato inválido.");
            } catch (IllegalArgumentException ex) {
                lblErro.setText(ex.getMessage());
            } catch (SQLException ex) {
                lblErro.setText("Erro no banco: " + ex.getMessage());
            }
        });

        Button btnCancelar = botao("Cancelar", "#7f8c8d");
        btnCancelar.setOnAction(e -> dialog.close());

        GridPane grid = new GridPane();
        grid.setHgap(10); grid.setVgap(8); grid.setPadding(new Insets(20));
        grid.addRow(0, new Label("Nome:"), fNome);
        grid.addRow(1, new Label("Descrição:"), fDesc);
        grid.addRow(2, new Label("Preço (R$):"), fPreco);
        grid.addRow(3, new Label("Estoque:"), fEstoque);
        grid.addRow(4, new Label("Imagem:"), fImg);
        GridPane.setHgrow(fNome, Priority.ALWAYS);
        GridPane.setHgrow(fDesc, Priority.ALWAYS);
        GridPane.setHgrow(fPreco, Priority.ALWAYS);
        GridPane.setHgrow(fEstoque, Priority.ALWAYS);
        GridPane.setHgrow(fImg, Priority.ALWAYS);

        HBox botoes = new HBox(8, btnSalvar, btnCancelar);
        VBox root = new VBox(12, grid, lblErro, botoes);
        root.setPadding(new Insets(10));

        dialog.setScene(new Scene(root, 420, 300));
        dialog.initOwner(tabelaProdutos.getScene().getWindow());
        dialog.showAndWait();
    }

    // ─── Aba Usuários ────────────────────────────────────────────────────────────

    private Tab criarAbaUsuarios() {
        Tab tab = new Tab("Usuários");

        TableView<Usuario> tabela = new TableView<>();
        ObservableList<Usuario> lista = FXCollections.observableArrayList();
        tabela.setItems(lista);
        tabela.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Usuario, Integer> colId = new TableColumn<>("ID");
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colId.setMaxWidth(60);

        TableColumn<Usuario, String> colNome = new TableColumn<>("Nome Completo");
        colNome.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getNomeCompleto()));

        TableColumn<Usuario, String> colLogin = new TableColumn<>("Login");
        colLogin.setCellValueFactory(new PropertyValueFactory<>("login"));

        tabela.getColumns().addAll(colId, colNome, colLogin);

        Button btnAtualizar = botao("↻ Atualizar Lista", "#7f8c8d");
        Button btnRemover   = botao("✕ Remover Usuário", "#e74c3c");

        Label lblStatusAba = new Label("Clique em 'Atualizar Lista' para carregar.");
        lblStatusAba.setStyle("-fx-text-fill: #555;");

        btnAtualizar.setOnAction(e -> {
            try {
                lista.setAll(usuarioService.listarUsuariosComuns());
                lblStatusAba.setText(lista.size() + " usuário(s) cadastrado(s).");
            } catch (SQLException ex) {
                alertaErro("Erro ao listar usuários: " + ex.getMessage());
            }
        });

        btnRemover.setOnAction(e -> {
            Usuario u = tabela.getSelectionModel().getSelectedItem();
            if (u == null) { lblStatusAba.setText("Selecione um usuário para remover."); return; }

            Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                    "Remover usuário \"" + u.getLogin() + "\"?", ButtonType.YES, ButtonType.NO);
            confirm.setHeaderText("Confirmar remoção");
            Optional<ButtonType> resp = confirm.showAndWait();

            if (resp.isPresent() && resp.get() == ButtonType.YES) {
                try {
                    boolean ok = usuarioService.removerUsuarioComum(u.getId());
                    lblStatusAba.setText(ok ? "Usuário removido." : "Usuário não encontrado.");
                    lista.setAll(usuarioService.listarUsuariosComuns());
                } catch (SQLException ex) {
                    alertaErro("Erro ao remover: " + ex.getMessage());
                }
            }
        });

        HBox acoes = new HBox(8, btnAtualizar, btnRemover);
        VBox conteudo = new VBox(10, tabela, acoes, lblStatusAba);
        conteudo.setPadding(new Insets(14));
        VBox.setVgrow(tabela, Priority.ALWAYS);

        tab.setContent(conteudo);
        return tab;
    }

    // ─── Utilitários ─────────────────────────────────────────────────────────────

    private Button botao(String texto, String cor) {
        Button b = new Button(texto);
        b.setStyle("-fx-background-color: " + cor + "; -fx-text-fill: white; -fx-background-radius: 5; -fx-padding: 6 14;");
        return b;
    }

    private TextField campo(String valor, String prompt) {
        TextField tf = new TextField(valor);
        tf.setPromptText(prompt);
        tf.setPrefHeight(32);
        return tf;
    }

    private void setStatus(String msg) {
        if (lblStatus != null) lblStatus.setText(msg);
    }

    private void alertaErro(String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR, msg, ButtonType.OK);
        alert.setHeaderText("Erro");
        alert.showAndWait();
    }
}
