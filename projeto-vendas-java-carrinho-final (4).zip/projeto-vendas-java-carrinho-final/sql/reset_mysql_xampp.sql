DROP DATABASE IF EXISTS projeto_vendas;
CREATE DATABASE projeto_vendas
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE projeto_vendas;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    sobrenome VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('USUARIO', 'ADMIN') NOT NULL DEFAULT 'USUARIO'
);

CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0,
    img VARCHAR(500),
    CONSTRAINT chk_produtos_preco CHECK (preco > 0),
    CONSTRAINT chk_produtos_estoque CHECK (estoque >= 0)
);

CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_pedido DATETIME NOT NULL,
    status ENUM('CONFIRMADO', 'CANCELADO') NOT NULL DEFAULT 'CONFIRMADO',
    total DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_pedidos_usuario_id_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE pedido_produto (
    pedido_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (pedido_id, produto_id),
    CONSTRAINT fk_pedido_produto_pedido_id_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    CONSTRAINT fk_pedido_produto_produto_id_produtos FOREIGN KEY (produto_id) REFERENCES produtos(id),
    CONSTRAINT chk_pedido_produto_quantidade CHECK (quantidade > 0),
    CONSTRAINT chk_pedido_produto_preco CHECK (preco_unitario > 0)
);

INSERT INTO usuarios (nome, sobrenome, login, senha, tipo) VALUES
('Admin', 'Sistema', 'admin', '12345678', 'ADMIN'),
('Usuario', 'Teste', 'usuario', '12345678', 'USUARIO');

INSERT INTO produtos (nome, descricao, preco, estoque, img) VALUES
('Camiseta Lisa', 'Camiseta basica tamanho P', 12.90, 20, 'camiseta.png'),
('Calca Jeans', 'Calca jeans masculina', 89.90, 15, 'calca.png'),
('Tenis Casual', 'Tenis casual branco', 149.90, 8, 'tenis.png');
