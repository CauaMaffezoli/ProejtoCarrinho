CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    sobrenome VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo VARCHAR(20) NOT NULL DEFAULT 'USUARIO',
    CONSTRAINT chk_usuarios_tipo CHECK (tipo IN ('USUARIO', 'ADMIN'))
);

CREATE TABLE IF NOT EXISTS produtos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    estoque INTEGER NOT NULL DEFAULT 0,
    img VARCHAR(500),
    CONSTRAINT chk_produtos_preco CHECK (preco > 0),
    CONSTRAINT chk_produtos_estoque CHECK (estoque >= 0)
);

CREATE TABLE IF NOT EXISTS pedidos (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL,
    data_pedido TIMESTAMP NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'CONFIRMADO',
    total DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_pedidos_status CHECK (status IN ('CONFIRMADO', 'CANCELADO')),
    CONSTRAINT fk_pedidos_usuario_id_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS pedido_produto (
    pedido_id INTEGER NOT NULL,
    produto_id INTEGER NOT NULL,
    quantidade INTEGER NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (pedido_id, produto_id),
    CONSTRAINT fk_pedido_produto_pedido_id_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    CONSTRAINT fk_pedido_produto_produto_id_produtos FOREIGN KEY (produto_id) REFERENCES produtos(id),
    CONSTRAINT chk_pedido_produto_quantidade CHECK (quantidade > 0),
    CONSTRAINT chk_pedido_produto_preco CHECK (preco_unitario > 0)
);

INSERT INTO usuarios (nome, sobrenome, login, senha, tipo)
VALUES ('Admin', 'Sistema', 'admin', '12345678', 'ADMIN')
ON CONFLICT (login) DO UPDATE SET
    nome = EXCLUDED.nome,
    sobrenome = EXCLUDED.sobrenome,
    senha = EXCLUDED.senha,
    tipo = EXCLUDED.tipo;

INSERT INTO usuarios (nome, sobrenome, login, senha, tipo)
VALUES ('Usuario', 'Teste', 'usuario', '12345678', 'USUARIO')
ON CONFLICT (login) DO UPDATE SET
    nome = EXCLUDED.nome,
    sobrenome = EXCLUDED.sobrenome,
    senha = EXCLUDED.senha,
    tipo = EXCLUDED.tipo;

INSERT INTO produtos (id, nome, descricao, preco, estoque, img)
VALUES
(1, 'Camiseta Lisa', 'Camiseta basica tamanho P', 12.90, 20, 'camiseta.png'),
(2, 'Calca Jeans', 'Calca jeans masculina', 89.90, 15, 'calca.png'),
(3, 'Tenis Casual', 'Tenis casual branco', 149.90, 8, 'tenis.png')
ON CONFLICT (id) DO UPDATE SET
    nome = EXCLUDED.nome,
    descricao = EXCLUDED.descricao,
    preco = EXCLUDED.preco,
    estoque = EXCLUDED.estoque,
    img = EXCLUDED.img;

SELECT setval(pg_get_serial_sequence('produtos', 'id'), (SELECT MAX(id) FROM produtos));
SELECT setval(pg_get_serial_sequence('usuarios', 'id'), (SELECT MAX(id) FROM usuarios));
