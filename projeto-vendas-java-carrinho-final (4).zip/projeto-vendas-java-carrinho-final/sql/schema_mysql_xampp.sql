CREATE DATABASE IF NOT EXISTS projeto_vendas
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE projeto_vendas;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    sobrenome VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('USUARIO', 'ADMIN') NOT NULL DEFAULT 'USUARIO'
);

CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL DEFAULT 0,
    img VARCHAR(500),
    CONSTRAINT chk_produtos_preco CHECK (preco > 0),
    CONSTRAINT chk_produtos_estoque CHECK (estoque >= 0)
);

CREATE TABLE IF NOT EXISTS pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_pedido DATETIME NOT NULL,
    status ENUM('CONFIRMADO', 'CANCELADO') NOT NULL DEFAULT 'CONFIRMADO',
    total DECIMAL(10,2) NOT NULL,
    CONSTRAINT fk_pedidos_usuario_id_usuarios FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

CREATE TABLE IF NOT EXISTS pedido_produto (
    pedido_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    PRIMARY KEY (pedido_id, produto_id),
    CONSTRAINT fk_pedido_produto_pedido_id_pedidos FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    CONSTRAINT fk_pedido_produto_produto_id_produtos FOREIGN KEY (produto_id) REFERENCES produtos(id),
    CONSTRAINT chk_pedido_produto_quantidade CHECK (quantidade > 0),
    CONSTRAINT chk_pedido_produto_preco CHECK (preco_unitario > 0)
);

INSERT INTO usuarios (nome, sobrenome, login, senha, tipo)
VALUES ('Admin', 'Sistema', 'admin', '12345678', 'ADMIN')
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome),
    sobrenome = VALUES(sobrenome),
    senha = VALUES(senha),
    tipo = VALUES(tipo);

INSERT INTO usuarios (nome, sobrenome, login, senha, tipo)
VALUES ('Usuario', 'Teste', 'usuario', '12345678', 'USUARIO')
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome),
    sobrenome = VALUES(sobrenome),
    senha = VALUES(senha),
    tipo = VALUES(tipo);

INSERT INTO produtos (id, nome, descricao, preco, estoque, img)
VALUES
(1, 'Camiseta Lisa', 'Camiseta basica tamanho P', 12.90, 20, 'camiseta.png'),
(2, 'Calca Jeans', 'Calca jeans masculina', 89.90, 15, 'calca.png'),
(3, 'Tenis Casual', 'Tenis casual branco', 149.90, 8, 'tenis.png')
ON DUPLICATE KEY UPDATE
    nome = VALUES(nome),
    descricao = VALUES(descricao),
    preco = VALUES(preco),
    estoque = VALUES(estoque),
    img = VALUES(img);
