# Explicação para apresentar o projeto

## 1. O que o sistema faz

Este sistema simula uma loja desktop feita em Java. Ele possui cadastro de usuários, login comum, login administrativo, gerenciamento de produtos e carrinho de compras.

A parte do pagamento não foi feita, porque o sistema apenas confirma uma compra ou reserva, salvando o pedido no banco e baixando o estoque.

---

## 2. Arquitetura do projeto

O projeto foi separado em camadas:

- `model`: classes que representam os dados, como Usuario, Produto, Pedido e Carrinho.
- `dao`: classes responsáveis por acessar o banco de dados com JDBC.
- `service`: classes responsáveis pelas regras de negócio e validações.
- `config`: classe de conexão com o banco.
- `app`: menus e fluxo do sistema.
- `util`: leitura de dados e formatação de moeda.

Essa separação ajuda a não deixar tudo misturado dentro de uma única classe.

---

## 3. Onde está a conexão com o banco

A conexão fica em:

```text
ConnectionFactory.java
```

Essa classe usa `DriverManager.getConnection()` para abrir a conexão com o banco. O padrão está configurado para XAMPP/MySQL:

```text
jdbc:mysql://localhost:3306/projeto_vendas
```

Se a professora usar PostgreSQL, basta trocar a configuração no próprio arquivo.

---

## 4. Como funciona o cadastro de usuário

O cadastro começa no `AppController`, no método `cadastrarUsuario()`.

O sistema pede:

- nome;
- sobrenome;
- login;
- senha;
- confirmação de senha.

Depois o `UsuarioService` valida:

- se os campos estão preenchidos;
- se a senha tem no mínimo 8 caracteres;
- se a senha e a confirmação são iguais;
- se já existe outro usuário com o mesmo login.

Se estiver tudo certo, o `UsuarioDAO` grava o usuário na tabela `usuarios`.

---

## 5. Como funciona o login

O login começa no método `efetuarLogin()` do `AppController`.

O usuário informa login e senha. O sistema chama o `UsuarioService`, que chama o `UsuarioDAO`.

O DAO executa um SELECT na tabela `usuarios`, verificando:

- login;
- senha;
- tipo do usuário.

Se for login comum, entra na loja. Se for login administrativo, entra na área administrativa.

---

## 6. Como funciona a área administrativa

Na área administrativa existem opções para:

- cadastrar produto;
- buscar produto;
- remover produto;
- atualizar produto;
- listar produtos;
- listar usuários;
- remover usuário comum.

As funções de produto usam o `ProdutoService` e o `ProdutoDAO`.

O `ProdutoDAO` é quem executa os comandos SQL:

- INSERT para cadastrar;
- SELECT para buscar;
- UPDATE para atualizar;
- DELETE para remover.

---

## 7. Como funciona a busca de produto

O usuário pode buscar por nome ou por ID.

A busca fica no método `buscarProduto()` do `AppController`.

O sistema manda o termo para o `ProdutoService`, que manda para o `ProdutoDAO`.

Se o termo digitado for número, busca por ID. Se for texto, busca por nome usando LIKE.

Se não encontrar nada, aparece:

```text
Produto Nao Encontrado
```

---

## 8. Como funciona o carrinho

O carrinho usa as classes:

```text
Carrinho.java
CarrinhoItem.java
```

O carrinho fica na memória enquanto o usuário está logado.

Quando o usuário adiciona um produto, o sistema:

1. busca o produto pelo ID;
2. verifica se existe;
3. verifica se tem estoque;
4. verifica se a quantidade desejada não passa do estoque;
5. adiciona o produto no carrinho.

Se o produto já estiver no carrinho, ele soma a quantidade.

---

## 9. Como funciona a confirmação da compra

A confirmação fica no `PedidoService.java`, no método `confirmarCompra()`.

Quando o usuário confirma, o sistema:

1. abre conexão com o banco;
2. inicia uma transação com `setAutoCommit(false)`;
3. verifica de novo o estoque dos produtos;
4. grava o pedido na tabela `pedidos`;
5. grava os itens na tabela `pedido_produto`;
6. baixa o estoque na tabela `produtos`;
7. confirma tudo com `commit()`;
8. limpa o carrinho.

Se der erro em qualquer etapa, o sistema faz `rollback()` e desfaz tudo.

Isso é importante porque evita salvar um pedido pela metade.

---

## 10. Tabelas usadas

### usuarios

Guarda os usuários do sistema.

Campos principais:

- id;
- nome;
- sobrenome;
- login;
- senha;
- tipo.

### produtos

Guarda os produtos da loja.

Campos principais:

- id;
- nome;
- descricao;
- preco;
- estoque;
- img.

### pedidos

Guarda o cabeçalho da compra/reserva.

Campos principais:

- id;
- usuario_id;
- data_pedido;
- status;
- total.

### pedido_produto

Guarda quais produtos fazem parte de cada pedido.

Campos principais:

- pedido_id;
- produto_id;
- quantidade;
- preco_unitario.

---

## 11. Perguntas que podem fazer

### O que é DAO?

DAO é uma classe responsável por acessar o banco de dados. Ela separa os comandos SQL do restante do sistema.

### O que é JDBC?

JDBC é a tecnologia do Java usada para conectar e executar comandos no banco de dados.

### Por que usar Service?

O Service concentra as regras de negócio e validações, evitando colocar tudo no menu ou diretamente no DAO.

### O que acontece quando confirma a compra?

O sistema cria o pedido, grava os itens e baixa o estoque.

### Por que usar transação?

Para garantir que todas as etapas da compra sejam salvas juntas. Se der erro, o sistema desfaz tudo.

### O pagamento foi implementado?

Não. A confirmação apenas registra a compra/reserva no banco, sem pagamento.
