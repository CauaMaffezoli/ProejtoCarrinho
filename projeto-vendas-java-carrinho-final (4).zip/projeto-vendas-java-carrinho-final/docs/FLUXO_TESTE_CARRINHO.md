# Fluxo de teste do carrinho

Use este roteiro para testar na apresentação.

## 1. Rodar o SQL

No XAMPP/phpMyAdmin, execute:

```text
sql/schema_mysql_xampp.sql
```

Se já existir banco antigo com problema, execute:

```text
sql/reset_mysql_xampp.sql
```

## 2. Entrar como usuário comum

```text
Login: usuario
Senha: 12345678
```

## 3. Buscar produto

Escolha:

```text
1 - Buscar produto
```

Digite:

```text
camiseta
```

O sistema deve mostrar o produto Camiseta Lisa.

## 4. Adicionar ao carrinho

Escolha:

```text
2 - Adicionar produto ao carrinho
```

Digite:

```text
ID: 1
Quantidade: 2
```

O sistema deve mostrar:

```text
Produto adicionado ao carrinho!
```

## 5. Visualizar carrinho

Escolha:

```text
4 - Visualizar carrinho
```

O sistema deve mostrar o produto, quantidade, preço, subtotal e total.

## 6. Remover produto do carrinho

Escolha:

```text
3 - Remover produto do carrinho
```

Digite o ID do produto.

## 7. Confirmar compra/reserva

Adicione o produto novamente e escolha:

```text
5 - Confirmar compra/reserva
```

Confirme com:

```text
S
```

O sistema deve mostrar:

```text
Compra/reserva confirmada com sucesso!
Numero do pedido: X
Estoque atualizado no banco de dados.
```

## 8. Conferir no banco

No phpMyAdmin, veja as tabelas:

```text
pedidos
pedido_produto
produtos
```

Você vai perceber que:

- um pedido foi criado;
- os itens foram salvos em `pedido_produto`;
- o estoque do produto diminuiu.
