# Projeto Desktop de Vendas - Java + JDBC + DAO

Este projeto foi feito para funcionar em console, porque o enunciado pede Java orientado a objetos, JDBC e DAO, e informa que a interface gráfica não precisa ser entregue nesta etapa.

## O que está funcionando

- Cadastro de novo usuário comum.
- Login de usuário comum.
- Login administrativo.
- Cadastro de produto.
- Busca de produto por nome ou ID.
- Atualização de produto.
- Remoção de produto.
- Listagem de produtos.
- Listagem de usuários comuns.
- Remoção de usuário comum.
- Carrinho de compras completo:
  - buscar produto;
  - adicionar produto ao carrinho;
  - remover produto do carrinho;
  - visualizar carrinho;
  - confirmar compra/reserva;
  - salvar pedido no banco;
  - salvar os produtos do pedido na tabela `pedido_produto`;
  - baixar o estoque automaticamente.

Não existe pagamento, como solicitado. A confirmação apenas gera o pedido/reserva e baixa o estoque.

---

# Banco de dados

## Se estiver usando XAMPP

O XAMPP normalmente usa MySQL/MariaDB pelo phpMyAdmin.

1. Abra o XAMPP.
2. Ligue Apache e MySQL.
3. Acesse `http://localhost/phpmyadmin`.
4. Entre na aba SQL.
5. Execute o arquivo:

```text
sql/schema_mysql_xampp.sql
```

Se você já rodou versões antigas e o banco ficou bagunçado, use este arquivo para apagar e recriar tudo:

```text
sql/reset_mysql_xampp.sql
```

Cuidado: o `reset_mysql_xampp.sql` apaga o banco `projeto_vendas` e cria tudo de novo.

## Se estiver usando PostgreSQL / pgAdmin

1. Crie um banco chamado `projeto_vendas` no pgAdmin.
2. Execute o arquivo:

```text
sql/schema_postgresql_pgadmin.sql
```

3. Depois altere o arquivo:

```text
src/main/java/br/com/projetovendas/config/ConnectionFactory.java
```

Comente a configuração MySQL e descomente a configuração PostgreSQL.

---

# Login de teste

## Administrador

```text
Login: admin
Senha: 12345678
```

## Usuário comum

```text
Login: usuario
Senha: 12345678
```

O login aceita maiúsculo/minúsculo. Então `ADMIN`, `Admin` e `admin` funcionam.

---

# Como rodar no IntelliJ com Maven

1. Abra o IntelliJ.
2. Clique em Open.
3. Selecione a pasta do projeto.
4. Espere o Maven baixar as dependências.
5. Rode a classe:

```text
src/main/java/br/com/projetovendas/app/Main.java
```

Ou pelo terminal, dentro da pasta do projeto:

```bash
mvn clean compile exec:java
```

---

# Como rodar sem Maven

Você vai precisar adicionar manualmente o driver JDBC do MySQL ou do PostgreSQL no projeto.

Para XAMPP/MySQL, o driver é o MySQL Connector/J.

Se usar Maven, isso já fica automático por causa do arquivo `pom.xml`.

---

# Onde fica cada parte do sistema

## Main

```text
src/main/java/br/com/projetovendas/app/Main.java
```

É o ponto inicial do programa.

## Menus e interação com o usuário

```text
src/main/java/br/com/projetovendas/app/AppController.java
```

Aqui estão os menus:

- menu principal;
- login;
- área administrativa;
- loja do cliente;
- carrinho de compras.

## Conexão com o banco

```text
src/main/java/br/com/projetovendas/config/ConnectionFactory.java
```

Esse arquivo abre a conexão JDBC com o banco.

## DAOs

```text
src/main/java/br/com/projetovendas/dao
```

Os DAOs fazem os comandos SQL no banco.

- `UsuarioDAO`: cadastro, login e listagem de usuários.
- `ProdutoDAO`: cadastro, busca, atualização, remoção e baixa de estoque.
- `PedidoDAO`: grava o pedido e os itens do pedido.

## Services

```text
src/main/java/br/com/projetovendas/service
```

Os Services ficam entre o menu e o DAO. Eles validam as regras antes de mandar para o banco.

- `UsuarioService`: valida cadastro e login.
- `ProdutoService`: valida produto.
- `PedidoService`: confirma compra, salva pedido e baixa estoque.

## Models

```text
src/main/java/br/com/projetovendas/model
```

São as classes que representam as tabelas e objetos do sistema.

- `Usuario`
- `Produto`
- `Pedido`
- `PedidoItem`
- `Carrinho`
- `CarrinhoItem`
- `TipoUsuario`

---

# Como funciona o carrinho

O carrinho fica na memória enquanto o usuário está logado.

Fluxo:

1. Usuário faz login.
2. Entra na loja.
3. Busca um produto.
4. Escolhe o ID do produto.
5. Informa a quantidade.
6. O sistema verifica se existe estoque.
7. O produto entra no carrinho.
8. O usuário pode remover produtos do carrinho.
9. Ao confirmar, o sistema salva o pedido no banco.
10. O sistema salva os itens na tabela `pedido_produto`.
11. O sistema baixa o estoque dos produtos.
12. O carrinho é limpo.

A parte principal está aqui:

```text
src/main/java/br/com/projetovendas/service/PedidoService.java
```

Ele usa transação. Isso significa que:

- se tudo der certo, o sistema salva o pedido e baixa o estoque;
- se der erro no meio, ele desfaz tudo com `rollback`.

Isso evita salvar pedido pela metade.
